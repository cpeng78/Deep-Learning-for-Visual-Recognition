rm -f assignment_2_part_2_submission.zip
zip -r assignment_2_part_2_submission.zip configs/ losses/*py  main.py  models/*py checkpoints/ 
