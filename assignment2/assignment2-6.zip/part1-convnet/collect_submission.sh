rm -f assignment_2_part_1_submission.zip
zip -r assignment_2_part_1_submission.zip modules/*py optimizer/*py trainer.py train.py
